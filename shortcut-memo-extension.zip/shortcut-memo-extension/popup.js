// Load memo on popup open
function loadMemo() {
  chrome.storage.local.get(['memo'], (result) => {
    document.getElementById('memo').value = result.memo || "";
  });
}
loadMemo();

document.getElementById('export').onclick = function() {
  chrome.storage.local.get(['memo'], (result) => {
    const memoText = result.memo || "";
    const blob = new Blob([memoText], {type: 'text/plain'});
    const url = URL.createObjectURL(blob);

    // Create a temporary link to download
    const a = document.createElement('a');
    a.href = url;
    a.download = 'memo.txt';
    a.click();

    // Cleanup
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
};

document.getElementById('clear').onclick = function() {
  chrome.storage.local.set({ memo: "" }, loadMemo);
};
