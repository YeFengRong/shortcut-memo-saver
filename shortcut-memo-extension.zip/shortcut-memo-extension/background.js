chrome.commands.onCommand.addListener((command) => {
  if (command === "add-to-memo") {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (!tabs.length) return;
      chrome.tabs.sendMessage(tabs[0].id, {action: "getSelection"}, (response) => {
        if (chrome.runtime.lastError || !response || !response.selection) return;
        addTextToMemo(response.selection);
      });
    });
  }
});

function addTextToMemo(selectedText) {
  if (!selectedText.trim()) return;
  chrome.storage.local.get(['memo'], (result) => {
    const currentMemo = result.memo || "";
    const newMemo = currentMemo + (currentMemo ? "\n" : "") + selectedText;
    chrome.storage.local.set({ memo: newMemo });
  });
}
